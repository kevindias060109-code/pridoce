import express from 'express';
import fs from 'fs';
import QRCode from 'qrcode';
import pino from 'pino';
import baileys from '@whiskeysockets/baileys';

const makeWASocket = baileys.default || baileys;
const { useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion } = baileys;

const PORT = process.env.PORT || 3000;
const SENHA = process.env.PAINEL_SENHA || 'troque-esta-senha';
const API_KEY = process.env.ANTHROPIC_API_KEY;
fs.mkdirSync('data', { recursive: true });

// ---------- "banco" simples em arquivo ----------
const DB_FILE = 'data/db.json';
const db = fs.existsSync(DB_FILE) ? JSON.parse(fs.readFileSync(DB_FILE)) : {};
db.contacts ??= []; db.pending ??= [];
db.settings ??= { feira: false, hora: 10, dias: [5], legenda: 'Oi! 😊 Nosso cardápio de hoje chegou! Qualquer dúvida é só chamar.', atrasoMin: 7, atrasoMax: 15, lastKey: '' };
const save = () => fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));

// ---------- WhatsApp ----------
let sock = null, status = 'desconectado', qr = null, pairingCode = null, phoneToPair = null;
let progress = { rodando: false, enviados: 0, total: 0 };

async function start() {
  const { state, saveCreds } = await useMultiFileAuthState('data/auth');
  const { version } = await fetchLatestBaileysVersion();
  sock = makeWASocket({ version, auth: state, logger: pino({ level: 'silent' }), browser: ['Bot Cardápio', 'Chrome', '1.0'] });
  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('connection.update', async ({ connection, lastDisconnect, qr: newQr }) => {
    if (newQr) {
      status = 'aguardando';
      if (phoneToPair && !sock.authState.creds.registered) {
        try { pairingCode = await sock.requestPairingCode(phoneToPair); } catch (e) { console.log(e.message); }
      } else qr = await QRCode.toDataURL(newQr);
    }
    if (connection === 'open') { status = 'conectado'; qr = null; pairingCode = null; }
    if (connection === 'close') {
      status = 'desconectado';
      const code = lastDisconnect?.error?.output?.statusCode;
      if (code === DisconnectReason.loggedOut) { fs.rmSync('data/auth', { recursive: true, force: true }); }
      setTimeout(start, 3000);
    }
  });

  const addContacts = (list) => {
    for (const c of list) {
      const id = c.id || c;
      if (typeof id === 'string' && id.endsWith('@s.whatsapp.net') && !db.contacts.includes(id)) db.contacts.push(id);
    }
    save();
  };
  sock.ev.on('contacts.upsert', addContacts);
  sock.ev.on('messaging-history.set', ({ contacts }) => contacts && addContacts(contacts));

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    for (const m of messages) {
      const jid = m.key.remoteJid;
      if (m.key.fromMe || !jid?.endsWith('@s.whatsapp.net')) continue; // ignora grupos
      const texto = m.message?.conversation || m.message?.extendedTextMessage?.text;
      if (!texto) continue;
      addContacts([jid]);
      try { await responder(jid, texto, m.pushName); } catch (e) { console.log('erro IA', e.message); }
    }
  });
}

// ---------- IA: responde só com base na imagem ----------
async function responder(jid, texto, nome) {
  if (!fs.existsSync('data/menu.b64')) return addPending(jid, nome, texto, 'duvida');
  const [mime, b64] = fs.readFileSync('data/menu.b64', 'utf8').split('|');
  const sistema = `Você é o atendente simpático, carismático e caloroso de um restaurante, falando por WhatsApp em português do Brasil, com emojis leves e frases curtas.
Use SOMENTE a imagem do cardápio como fonte (pratos, preços, ingredientes, opções).
Responda APENAS com JSON: {"tipo":"resposta"|"horario"|"duvida","texto":"..."}.
- "resposta": a imagem responde claramente à pergunta. Escreva a resposta em "texto".
- "horario": perguntam horário de funcionamento/abertura/fechamento/entrega. "texto" vazio.
- "duvida": a imagem não permite responder com certeza, ou o assunto é outro (endereço, pagamento, reclamação, etc.). "texto" vazio. NUNCA invente informação.
Se for só uma saudação, responda com tipo "resposta" cumprimentando com simpatia e oferecendo ajuda.`;
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-api-key': API_KEY, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({
      model: 'claude-sonnet-5', max_tokens: 500, system: sistema,
      messages: [{ role: 'user', content: [
        { type: 'image', source: { type: 'base64', media_type: mime, data: b64 } },
        { type: 'text', text: `Mensagem do cliente: "${texto}"` }] }]
    })
  });
  const data = await r.json();
  const raw = (data.content?.[0]?.text || '').replace(/```json|```/g, '').trim();
  let out; try { out = JSON.parse(raw); } catch { out = { tipo: 'duvida' }; }
  if (out.tipo === 'resposta' && out.texto) return sock.sendMessage(jid, { text: out.texto });
  if (out.tipo === 'horario') {
    await sock.sendMessage(jid, { text: 'Já vou confirmar o horário certinho pra você, um minutinho! 😊' });
    return addPending(jid, nome, texto, 'horario');
  }
  addPending(jid, nome, texto, 'duvida'); // dúvida: NÃO responde o cliente
}

function addPending(jid, nome, texto, tipo) {
  db.pending.push({ id: Date.now() + Math.random().toString(36).slice(2, 6), jid, nome: nome || jid.split('@')[0], texto, tipo, em: new Date().toISOString() });
  save();
}

// ---------- Transmissão um por um ----------
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
async function transmitir() {
  if (progress.rodando || status !== 'conectado' || !fs.existsSync('data/menu.b64')) return false;
  const [, b64] = fs.readFileSync('data/menu.b64', 'utf8').split('|');
  const img = Buffer.from(b64, 'base64');
  const lista = [...db.contacts];
  progress = { rodando: true, enviados: 0, total: lista.length };
  (async () => {
    for (const jid of lista) {
      try { await sock.sendMessage(jid, { image: img, caption: db.settings.legenda }); } catch (e) { console.log('falhou', jid); }
      progress.enviados++;
      const { atrasoMin: a, atrasoMax: b } = db.settings;
      await sleep((a + Math.random() * (b - a)) * 1000);
    }
    progress.rodando = false;
  })();
  return true;
}

// agenda: dias marcados (padrão sexta) na hora escolhida, 1x por dia
setInterval(() => {
  const d = new Date(), chave = d.toISOString().slice(0, 10);
  const { dias, hora, lastKey } = db.settings;
  if (dias.includes(d.getDay()) && d.getHours() >= hora && lastKey !== chave) {
    db.settings.lastKey = chave; save(); transmitir();
  }
}, 60000);

// ---------- API + painel ----------
const app = express();
app.use(express.json({ limit: '20mb' }));
app.use((req, res, next) => {
  const [, b64] = (req.headers.authorization || '').split(' ');
  const [, pass] = Buffer.from(b64 || '', 'base64').toString().split(':');
  if (pass === SENHA) return next();
  res.set('WWW-Authenticate', 'Basic realm="Painel"').status(401).send('Senha necessária');
});
app.use(express.static('public'));

app.get('/api/state', (req, res) => res.json({
  status, qr, pairingCode, progress, settings: db.settings, pending: db.pending,
  contatos: db.contacts.length, temCardapio: fs.existsSync('data/menu.b64'), temIA: !!API_KEY
}));
app.get('/api/menu', (req, res) => {
  if (!fs.existsSync('data/menu.b64')) return res.sendStatus(404);
  const [mime, b64] = fs.readFileSync('data/menu.b64', 'utf8').split('|');
  res.type(mime).send(Buffer.from(b64, 'base64'));
});
app.post('/api/pair', async (req, res) => {
  phoneToPair = (req.body.phone || '').replace(/\D/g, '') || null; qr = null; pairingCode = null;
  try { sock?.end?.(); } catch {}
  fs.rmSync('data/auth', { recursive: true, force: true });
  start(); res.json({ ok: true });
});
app.post('/api/menu', (req, res) => {
  const m = /^data:(image\/\w+);base64,(.+)$/.exec(req.body.dataUrl || '');
  if (!m) return res.status(400).json({ erro: 'imagem inválida' });
  fs.writeFileSync('data/menu.b64', `${m[1]}|${m[2]}`); res.json({ ok: true });
});
app.post('/api/settings', async (req, res) => {
  const antes = db.settings.feira;
  Object.assign(db.settings, req.body); save();
  if (!antes && db.settings.feira) transmitir(); // ligou o modo feira/festa → envia agora
  res.json({ ok: true });
});
app.post('/api/broadcast', async (req, res) => res.json({ ok: await transmitir() }));
app.post('/api/reply', async (req, res) => {
  const p = db.pending.find(x => x.id === req.body.id);
  if (p && req.body.text) { await sock.sendMessage(p.jid, { text: req.body.text }); db.pending = db.pending.filter(x => x !== p); save(); }
  res.json({ ok: true });
});
app.post('/api/dismiss', (req, res) => { db.pending = db.pending.filter(x => x.id !== req.body.id); save(); res.json({ ok: true }); });

app.listen(PORT, () => console.log(`Painel em http://localhost:${PORT}`));
start();
