# Bot do Cardápio (WhatsApp)

## Como rodar
1. Instale o Node.js 18+ (nodejs.org).
2. Nesta pasta: `npm install`
3. Copie `.env.example` para `.env` e preencha a chave (console.anthropic.com) e a senha do painel.
4. `node --env-file=.env server.js`
5. Abra http://localhost:3000 (usuário: qualquer; senha: a do .env), conecte por QR ou número, envie o cardápio.

Para funcionar 24h e receber avisos no celular: rode em um servidor barato (VPS/Railway/Render com disco) e abra o painel no celular (aceite as notificações e use "Adicionar à tela inicial").

## Como funciona
- Cliente pergunta algo que a imagem responde → bot responde simpático.
- Perguntou horário → aviso no painel; você digita o horário e o bot envia.
- Qualquer coisa que o bot não sabe → só aviso no painel, cliente não recebe nada.
- Sexta (hora configurável) ou ao ligar "Modo feira/festa" → envia a imagem um por um, com pausa aleatória entre envios.

## Importante
Usa a biblioteca não oficial Baileys. O WhatsApp pode banir números que enviam muitas mensagens seguidas ou para quem não pediu. Mantenha o intervalo de 7–15s (ou mais), envie só para clientes que já falaram com você e use um número secundário no começo.
